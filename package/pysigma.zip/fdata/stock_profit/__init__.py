a=[{'s':1},{'s':2}]
b=[{'a':2},{'a':3}]


ai=0;
bi=0
while ai<len(a) and b<len(b):
    print '-'*10
    ai+=1
    bi+=1